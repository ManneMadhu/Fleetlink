import React, { useState } from 'react';

function toISOFromLocal(value) {
  if (!value) return null;
  const d = new Date(value);
  return d.toISOString();
}

export default function SearchBook() {
  const [capacity, setCapacity] = useState('');
  const [fromPincode, setFromPincode] = useState('');
  const [toPincode, setToPincode] = useState('');
  const [startLocal, setStartLocal] = useState('');
  const [results, setResults] = useState([]);
  const [msg, setMsg] = useState(null);

  const handleSearch = async (e) => {
    e.preventDefault();
    const iso = toISOFromLocal(startLocal);
    const q = new URLSearchParams({ capacityRequired: capacity, fromPincode, toPincode, startTime: iso }).toString();
    try {
      setMsg('Searching...');
      const res = await fetch('http://localhost:5000/api/vehicles/available?' + q);
      const body = await res.json();
      if (!res.ok) throw new Error(body.error || 'Failed');
      setResults(body);
      setMsg(null);
    } catch (err) {
      setMsg('Error: ' + err.message);
    }
  };

  const handleBook = async (vehicleId) => {
    const iso = toISOFromLocal(startLocal);
    try {
      const res = await fetch('http://localhost:5000/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ vehicleId, fromPincode, toPincode, startTime: iso, customerId: 'demo-customer-1' })
      });
      const body = await res.json();
      if (!res.ok) throw new Error(body.error || 'Failed to book');
      setMsg('Booking successful! ID: ' + body._id);
      handleSearch(new Event('submit'));
    } catch (err) {
      setMsg('Booking error: ' + err.message);
    }
  };

  return (
    <div>
      <h2>Search & Book</h2>
      <form onSubmit={handleSearch}>
        <div>
          <label>Capacity Required</label><br />
          <input type='number' value={capacity} onChange={e => setCapacity(e.target.value)} required />
        </div>
        <div>
          <label>From Pincode</label><br />
          <input value={fromPincode} onChange={e => setFromPincode(e.target.value)} required />
        </div>
        <div>
          <label>To Pincode</label><br />
          <input value={toPincode} onChange={e => setToPincode(e.target.value)} required />
        </div>
        <div>
          <label>Start Date & Time</label><br />
          <input type='datetime-local' value={startLocal} onChange={e => setStartLocal(e.target.value)} required />
        </div>
        <button type='submit'>Search Availability</button>
      </form>

      {msg && <p>{msg}</p>}

      <h3>Results</h3>
      <div>
        {results.length === 0 && <p>No vehicles available</p>}
        {results.map(v => (
          <div key={v._id} style={{ border: '1px solid #ddd', padding: 8, marginBottom: 6 }}>
            <div><strong>{v.name}</strong></div>
            <div>Capacity: {v.capacityKg} kg</div>
            <div>Tyres: {v.tyres}</div>
            <div>Estimated Duration (hours): {v.estimatedRideDurationHours}</div>
            <button onClick={() => handleBook(v._id)}>Book Now</button>
          </div>
        ))}
      </div>
    </div>
  );
}
