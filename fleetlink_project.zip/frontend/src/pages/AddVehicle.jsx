import React, { useState } from 'react';

export default function AddVehicle() {
  const [name, setName] = useState('');
  const [capacity, setCapacity] = useState('');
  const [tyres, setTyres] = useState('');
  const [message, setMessage] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch('http://localhost:5000/api/vehicles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, capacityKg: Number(capacity), tyres: Number(tyres) })
      });
      const body = await res.json();
      if (!res.ok) throw new Error(body.error || 'Failed');
      setMessage('Vehicle added: ' + body.name);
      setName(''); setCapacity(''); setTyres('');
    } catch (err) {
      setMessage('Error: ' + err.message);
    }
  };

  return (
    <div>
      <h2>Add Vehicle</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Name</label><br />
          <input value={name} onChange={e => setName(e.target.value)} required />
        </div>
        <div>
          <label>Capacity (KG)</label><br />
          <input type='number' value={capacity} onChange={e => setCapacity(e.target.value)} required />
        </div>
        <div>
          <label>Tyres</label><br />
          <input type='number' value={tyres} onChange={e => setTyres(e.target.value)} required />
        </div>
        <button type='submit'>Add</button>
      </form>
      {message && <p>{message}</p>}
    </div>
  );
}
