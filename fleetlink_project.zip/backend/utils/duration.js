function estimatedRideDurationHours(fromPincode, toPincode) {
  const a = parseInt(fromPincode, 10);
  const b = parseInt(toPincode, 10);
  if (Number.isNaN(a) || Number.isNaN(b)) {
    throw new Error('Invalid pincode(s)');
  }
  return Math.abs(b - a) % 24;
}

module.exports = { estimatedRideDurationHours };