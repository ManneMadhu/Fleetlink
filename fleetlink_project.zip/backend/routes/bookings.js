const express = require('express');
const mongoose = require('mongoose');
const Vehicle = require('../models/Vehicle');
const Booking = require('../models/Booking');
const { estimatedRideDurationHours } = require('../utils/duration');

const router = express.Router();

router.post('/', async (req, res, next) => {
  const session = await mongoose.startSession();
  try {
    const { vehicleId, fromPincode, toPincode, startTime, customerId } = req.body;
    if (!vehicleId || !fromPincode || !toPincode || !startTime || !customerId) {
      return res.status(400).json({ error: 'vehicleId, fromPincode, toPincode, startTime and customerId are required' });
    }

    const vehicle = await Vehicle.findById(vehicleId);
    if (!vehicle) return res.status(404).json({ error: 'Vehicle not found' });

    const estimated = estimatedRideDurationHours(fromPincode, toPincode);
    const start = new Date(startTime);
    if (Number.isNaN(start.getTime())) return res.status(400).json({ error: 'Invalid startTime' });
    const end = new Date(start);
    end.setHours(end.getHours() + estimated);

    await session.startTransaction();

    const conflict = await Booking.findOne({
      vehicleId: vehicle._id,
      startTime: { $lt: end },
      endTime: { $gt: start }
    }).session(session);

    if (conflict) {
      await session.abortTransaction();
      session.endSession();
      return res.status(409).json({ error: 'Vehicle already booked for requested time' });
    }

    const bookingDoc = {
      vehicleId: vehicle._id,
      fromPincode,
      toPincode,
      startTime: start,
      endTime: end,
      customerId,
      estimatedRideDurationHours: estimated
    };

    const [created] = await Booking.create([bookingDoc], { session });

    await session.commitTransaction();
    session.endSession();

    return res.status(201).json(created);
  } catch (err) {
    try {
      await session.abortTransaction();
      session.endSession();
    } catch (_) {}
    next(err);
  }
});

module.exports = router;